# SE Pool Free

مشروع Flutter مستقل بواجهة داكنة وزرقاء مستوحاة من أسلوب التطبيق المرفق، ويعرض خياراً واحداً فقط: 8 Ball Pool الرسمية.

- لا يحتوي على SnakeEngine API أو تسجيل دخول أو تحقق اشتراك أو تحليلات أو خوادم وسيطة.
- يحاول فتح الحزمة الرسمية `com.miniclip.eightballpool`، وإذا لم تكن مثبتة يفتح صفحة Google Play.
- اللعبة الرسمية نفسها قد تتصل بخوادمها الخاصة؛ هذا المشروع لا يعدل اللعبة ولا يعطل اتصالاتها.

## البناء
يتطلب Flutter SDK وAndroid SDK. من مجلد المشروع شغّل:

```sh
flutter pub get
flutter build apk --release
```

الناتج: `build/app/outputs/flutter-apk/app-release.apk`
