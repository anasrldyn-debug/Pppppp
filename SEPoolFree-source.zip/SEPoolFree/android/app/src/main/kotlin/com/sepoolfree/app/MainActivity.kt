package com.sepoolfree.app

import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.sepoolfree/launcher").setMethodCallHandler { call, result ->
            if (call.method != "openPool") { result.notImplemented(); return@setMethodCallHandler }
            val gamePackage = "com.miniclip.eightballpool"
            try {
                val launch = packageManager.getLaunchIntentForPackage(gamePackage)
                if (launch != null) startActivity(launch) else {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$gamePackage"))) }
                    catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$gamePackage"))) }
                }
                result.success(true)
            } catch (e: Exception) { result.error("OPEN_FAILED", e.message, null) }
        }
    }
}
