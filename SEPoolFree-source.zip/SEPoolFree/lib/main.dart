import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const SEPoolFreeApp());

class SEPoolFreeApp extends StatelessWidget {
  const SEPoolFreeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SE Pool Free',
    theme: ThemeData(brightness: Brightness.dark, scaffoldBackgroundColor: const Color(0xFF080B12), colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF168BFF), brightness: Brightness.dark), useMaterial3: true),
    home: const PoolHome(),
  );
}

class PoolHome extends StatefulWidget {
  const PoolHome({super.key});
  @override
  State<PoolHome> createState() => _PoolHomeState();
}

class _PoolHomeState extends State<PoolHome> {
  static const platform = MethodChannel('com.sepoolfree/launcher');
  bool launching = false;
  Future<void> openPool() async {
    setState(() => launching = true);
    try { await platform.invokeMethod<bool>('openPool'); }
    on PlatformException {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح اللعبة. تحقق من تثبيت النسخة الرسمية.')));
    } finally { if (mounted) setState(() => launching = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 480), child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const SizedBox(height: 28),
    const Icon(Icons.sports_esports_rounded, size: 46, color: Color(0xFF168BFF)),
    const SizedBox(height: 12),
    const Text('SE POOL FREE', textAlign: TextAlign.center, style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, letterSpacing: 2)),
    const SizedBox(height: 7),
    Text('نسخة بسيطة تعمل دون حساب أو اتصال بسيرفرات وسيطة', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.62), fontSize: 13)),
    const Spacer(),
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFF121A29), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF263A55))), child: Column(children: [
      Container(width: 84, height: 84, decoration: BoxDecoration(color: const Color(0xFF0A633F), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.sports_bar_rounded, size: 48, color: Colors.white)),
      const SizedBox(height: 16),
      const Text('8 Ball Pool', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      const Text('اللعبة الرسمية فقط', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 20),
      SizedBox(width: double.infinity, height: 52, child: FilledButton.icon(onPressed: launching ? null : openPool, icon: launching ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow_rounded), label: Text(launching ? 'جارٍ الفتح...' : 'تشغيل اللعبة'))),
    ])),
    const Spacer(),
    const Text('لا توجد خدمات Gold أو اشتراكات أو خوادم خارجية داخل هذا التطبيق.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 11)),
    const SizedBox(height: 12),
  ]))))));
}
